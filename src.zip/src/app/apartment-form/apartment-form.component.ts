// src/app/apartment-form/apartment-form.component.ts
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApartmentService } from '../apartment.service';


@Component({
  selector: 'app-apartment-form',
  templateUrl: './apartment-form.component.html',
  styleUrls: ['./apartment-form.component.css']
})
export class ApartmentFormComponent implements OnInit {
  apartmentForm!: FormGroup;

  constructor(
    private fb: FormBuilder,
    private apartmentService: ApartmentService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.apartmentForm = this.fb.group({
      title: ['', Validators.required],
      description: ['', Validators.required],
      photo: ['', Validators.required],
      rentalTerms: ['', Validators.required],
      contactInfo: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.apartmentForm.valid) {
      this.apartmentService.addApartment(this.apartmentForm.value).subscribe({
        next: response => {
          console.log('Apartment posted successfully', response);
          this.router.navigate(['/home']);
        },
        error: error => {
          console.error('Failed to post apartment', error);
        }
      });
    }
  }
}
