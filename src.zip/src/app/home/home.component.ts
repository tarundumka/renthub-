import { Component, OnInit } from '@angular/core';
import { RentalHouseService } from '../rental-house.service';
import { ApartmentService } from '../apartment.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

apartments:any[]=[];
  // apartmentService: any;

  constructor(private apartmentService: ApartmentService) { }

  ngOnInit(): void {
    this.apartmentService.getApartment().subscribe(apartments => {
      this.apartments = apartments;
    });
    

  }
  viewDetails(id: number): void {
    console.log('View details for house with id:', id);
    // Implement navigation or other logic to view house details
  }

  markAsFavourite(house: any): void {
    console.log('Marked as favourite:', house.name);
    // Implement the logic to mark the house as favourite
  }
}
