import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private route: Router) { }

  ngOnInit(): void {
  }
  login() {
    this.route.navigate(['/login'])

    console.log('Login button clicked');
    // Implement your login logic here
  }

  register() {
    this.route.navigate(['/register'])
    console.log('Logout button clicked');
    // Implement your logout logic here
  }
  Add(){
    this.route.navigate(['/apartment-form'])
    console.log('add form ');
  }

}
